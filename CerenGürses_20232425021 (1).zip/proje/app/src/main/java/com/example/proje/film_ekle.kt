package com.example.proje

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.proje.databinding.ActivityFilmEkleBinding

class FilmEkleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFilmEkleBinding
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilmEkleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = DatabaseHelper(this)

        binding.filmKaydetButton.setOnClickListener {
            val ad = binding.filmAdiEditText.text.toString()
            val yorum = binding.filmYorumEditText.text.toString()
            val puan = binding.puanRatingBar.rating.toInt()

            if (ad.isNotEmpty()) {
                val film = Film(ad = ad, yorum = yorum, puan = puan)
                val basarili = databaseHelper.filmEkle(film)
                if (basarili) {
                    Toast.makeText(this, "Film kaydedildi", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "Kayıt başarısız", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Film adı boş olamaz", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
