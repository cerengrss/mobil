package com.example.yourappname

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.proje.Film
import com.example.proje.R

data class Film(val id: Int, val ad: String, val yorum: String, val puan: Int)

class FilmAdapter(private val filmList: List<Film>) : RecyclerView.Adapter<FilmAdapter.FilmViewHolder>() {

    class FilmViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val adText: TextView = itemView.findViewById(R.id.filmAd)
        val yorumText: TextView = itemView.findViewById(R.id.filmYorum)
        val puanText: TextView = itemView.findViewById(R.id.filmPuan)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_item_film, parent, false)
        return FilmViewHolder(view)
    }

    override fun onBindViewHolder(holder: FilmViewHolder, position: Int) {
        val film = filmList[position]
        holder.adText.text = film.ad
        holder.yorumText.text = film.yorum
        holder.puanText.text = "Puan: ${film.puan}"
    }

    override fun getItemCount() = filmList.size
}


