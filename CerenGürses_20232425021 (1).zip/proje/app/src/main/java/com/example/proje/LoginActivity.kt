package com.example.proje

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.proje.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {


    private lateinit var binding: ActivityLoginBinding
    private lateinit var databaseHelper: DatabaseHelper




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseHelper = DatabaseHelper(this)

        binding.girisyapButton.setOnClickListener{
            val girisyapKullancAd=binding.girisyapKullanCAd.text.toString()
            val girisyapSifre =binding.girisyapSifre.text.toString()
            loginDatabase(girisyapKullancAd,girisyapSifre)
        }
binding.kayTolRedirect.setOnClickListener{
    val intent = Intent(this,SignupActivity::class.java)
    startActivity(intent)
    finish()
}
    }

    private fun loginDatabase(username: String, password: String){
        val userExists = databaseHelper.readUser(username,password)
        if(userExists){
            Toast.makeText(this,"Giriş Başarılı",Toast.LENGTH_SHORT).show()
            val intent = Intent(this, AnaMenu::class.java)

            startActivity(intent)
            finish()
        }else{
            Toast.makeText(this,"Giriş Başarısız",Toast.LENGTH_SHORT).show()
        }
    }
}