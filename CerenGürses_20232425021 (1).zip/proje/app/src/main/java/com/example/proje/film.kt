package com.example.proje

data class Film(
    val id: Int = 0,
    val ad: String,
    val yorum: String,
    val puan: Int
)
