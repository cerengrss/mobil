package com.example.proje

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(private val context: Context):
           SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION){

    companion object{
        private const val DATABASE_NAME = "UserDatabase.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "data"
        private const val COLUMN_ID = "id"
        private const val COLUMN_USERNAME= "username"
        private const val COLUMN_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createUserTableQuery = """
        CREATE TABLE $TABLE_NAME (
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_USERNAME TEXT,
            $COLUMN_PASSWORD TEXT
        )
    """.trimIndent()

        val createFilmTableQuery = """
        CREATE TABLE IF NOT EXISTS Filmler (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ad TEXT,
            yorum TEXT,
            puan INTEGER
        )
    """.trimIndent()

        db?.execSQL(createUserTableQuery)
        db?.execSQL(createFilmTableQuery)
    }


    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val dropTableQuery = "DROP TABLE IF EXISTS $TABLE_NAME"
        db?.execSQL(dropTableQuery)
        onCreate(db)
    }
    fun insertUser(username: String, password: String): Long{
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        val db = writableDatabase
        return db.insert(TABLE_NAME, null, values)
    }
    fun readUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ? "
        val selectionArgs = arrayOf(username, password)
        val cursor = db.query(TABLE_NAME,null,selection,selectionArgs,null,null,null)


        val userExists = cursor.count > 0
        cursor.close()
        return userExists
    }


    fun filmEkle(film: Film): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("ad", film.ad)
            put("yorum", film.yorum)
            put("puan", film.puan)
        }
        val result = db.insert("Filmler", null, values)
        db.close()
        return result != -1L
    }

    fun tumFilmleriGetir(): List<Film> {
        val filmList = mutableListOf<Film>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM Filmler", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val ad = cursor.getString(cursor.getColumnIndexOrThrow("ad"))
                val yorum = cursor.getString(cursor.getColumnIndexOrThrow("yorum"))
                val puan = cursor.getInt(cursor.getColumnIndexOrThrow("puan"))
                filmList.add(Film(id, ad, yorum, puan))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return filmList
    }

    fun tumFilmleriSil(): Boolean {
        val db = this.writableDatabase
        val result = db.delete("filmler", null, null)
        db.close()
        return result > 0
    }



}