package com.example.proje

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.yourappname.FilmAdapter


class FilmlerimActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FilmAdapter
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var filmList: List<Film>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filmlerim)

        recyclerView = findViewById(R.id.filmRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        databaseHelper = DatabaseHelper(this)
        filmList = databaseHelper.tumFilmleriGetir()
        adapter = FilmAdapter(filmList)
        recyclerView.adapter = adapter
        val btnTemizle = findViewById<Button>(R.id.btnTemizle)
        btnTemizle.setOnClickListener {
            val silindi = databaseHelper.tumFilmleriSil()
            if (silindi) {
                Toast.makeText(this, "Tüm filmler silindi", Toast.LENGTH_SHORT).show()
                filmList = emptyList()
                adapter = FilmAdapter(filmList)
                recyclerView.adapter = adapter
            } else {
                Toast.makeText(this, "Silme işlemi başarısız", Toast.LENGTH_SHORT).show()
            }
        }

    }
}
